<?php

return [
    '1' => 'Home',
    '2' => 'About',
    '3' => 'Tours',
    '4' => 'Rentals',
    '5'=>'Contact',
    'lang'=>url('lang',['es']),
    'imgLeng'=>url('/images/esp.png'),
    'tel'=>'Phone',
    'txtDir'=>'Address',
    'dir'=>'I dont\' know'
];
