<?php

return [
    '1' => 'Inicio',
    '2' => 'Nosotros',
    '3' => 'Tours',
    '4' => 'Rentas',
    '5'=>'Contacto',
    'lang'=>url('lang',['en']),
    'imgLeng'=>url('/images/eng.png'),
    'tel'=>'Tel',
    'txtDir'=>'Dirección',
    'dir'=>'No lo sé'
];
