@extends('layouts.master')

@section('css')
    <link href="<?php echo url('/css/about.css');?>" rel="stylesheet">
@endsection

@section('cuerpo')
    <div id="cuerpo">

    </div>
@endsection

@section('js')
    <script src="<?php echo url('/js/about.js')?>"></script>
@endsection