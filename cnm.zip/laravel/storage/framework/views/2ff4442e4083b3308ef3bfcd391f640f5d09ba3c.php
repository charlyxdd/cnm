<?php $__env->startSection('css'); ?>
    <link href="<?php echo url('/css/about.css');?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cuerpo'); ?>
    <div id="cuerpo">

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo url('/js/about.js')?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>