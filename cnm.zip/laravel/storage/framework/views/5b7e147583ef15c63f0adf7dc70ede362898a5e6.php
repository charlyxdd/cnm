<header>
    <div id="socialContainer">
        <div>
            <a href="<?php echo e(trans('header.lang')); ?>">
                <img src="<?php echo e(trans('header.imgLeng')); ?>">
            </a>
            <a href="#" id="cmdFb">
                <img src="<?php echo url('/images/fbblack.png');?>">
            </a>
            <a href="#" id="cmdTw">
                <img src="<?php echo url('/images/twitterblack.png');?>">
            </a>

            <p><?php echo e(trans('header.tel')); ?>: +52 (987) 877 1927</p>
            <p><?php echo e(trans('header.txtDir')); ?>:<?php echo e(trans('header.dir')); ?></p>
        </div>
    </div>
    <div id="headerContainer">
        <div id="logoContainer">
            <a href="<?php echo url('/');?>">
                <img src="<?php echo url('/images/logo.png')?>">
            </a>
        </div>
        <div id="navContainer">
            <nav>
                <!--
                Inicio
                Galeria
                Acerca de nosotros
                Contacto
                !-->
                <a href="<?php echo url('/')?>">
                    <?php echo e(trans('header.1')); ?>

                </a>

                <a href="<?php echo url('/about')?>">
                    <?php echo e(trans('header.2')); ?>

                </a>

                <a href="#">
                    <?php echo e(trans('header.3')); ?>

                </a>

                <a href="#">
                    <?php echo e(trans('header.4')); ?>

                </a>

                <a href="#">
                    <?php echo e(trans('header.5')); ?>

                </a>
            </nav>
        </div>
    </div>
</header>